num1=int(input('Δώσε 1ο αριθμό: '));
num2=int(input('Δώσε 2ο αριθμό: '));
num3=int(input('Δώσε 3ο αριθμό: '));

summ=num1+num2+num3;
mult=num1*num2*num3;

print('Το άθροισμα τους είναι: ',summ,'.',sep="",end=" ");
print('Το γινόμενο τους είναι: ',mult,sep="");

print('Το άθροισμα τους ειναι: %d. Το γινόμενο τους ειναι: %d' % (summ,mult));

print('Το άθροισμα τους ειναι: {0}. Το γινόμενο τους ειναι: {1}' .format(summ,mult));
