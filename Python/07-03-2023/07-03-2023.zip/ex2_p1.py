base=int(input('Βάση τριγώνου: '));
height=int(input('Δώσε Ύψος: '));

print('Το εμβαδόν ειναι:', base*height/2, sep=" ")
print('Το εβμαδόν ειναι %f' %(base*height/2))
print('Το εβμαδόν ειναι {}' .format(base*height/2))


